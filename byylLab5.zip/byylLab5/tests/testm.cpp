int main(){
    while(1){
        int* i =new int[20];
    }
}