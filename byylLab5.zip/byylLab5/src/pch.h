// 导入要引用的头文件
#ifndef PCH_H
#define PCH_H

#include <cstdio>
#include <cmath>
#include <cctype>
#include <cstring>
#include <cstdlib>
#include <cstdarg>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
#include <list>
#include <assert.h>

#include <map>
#include <stack>
#include <unordered_map>

#endif
